USE CLASSICMODELS;
--  SELECT clause with WHERE, AND,DISTINCT, Wild Card (LIKE)
-- 1.	Fetch the employee number, first name and last name of those employees who are working as Sales Rep reporting to employee with  employeenumber 1102 (Refer employee table)
select EmployeeNumber,firstName,lastName from employees where reportsTo like 1102;

-- 2.	Show the unique productline values containing the word cars at the end from the products table.


select * from productlines;
select productline from productlines where productline like '%cars';

-- CASE STATEMENTS for Segmentation
-- . 1. Using a CASE statement, segment customers into three categories based on their country:(Refer Customers table)
                        
    


select * from customers;

select customerNumber,customerName,
case 
when country= 'USA' then 'North America'
when country = 'Canada' then 'North America'
when country = 'UK' THEN 'Europe'
when country= 'France' then 'Europe'
when country = 'germony' then 'Europe'
else 'other'
end  AS CustomerSegment
from customers;

-- Group By with Aggregation functions and Having clause, Date and Time functions
-- 1.	Using the OrderDetails table, identify the top 10 products (by productCode) with the highest total order quantity across all orders.


select *from orderdetails;
select productcode,sum(quantityOrdered) AS ORDER_TOTAL from orderdetails  group by productCode ORDER BY ORDER_TOTAL DESC
;
-- 2.	Company wants to analyze payment frequency by month. Extract the month name from the payment date to count the total number of payments for each month and include only those months with a payment count exceeding 20 (Refer Payments table). 

SELECT * FROM payments;
SELECT monthname(PaymentDate) as month_NAME,COUNT(*) AS TOTALPAYMENTS FROM PAYMENTS GROUP BY month(paymentdate) having TOTALPAYMENTS >20 ;


-- CONSTRAINTS: Primary, key, foreign key, Unique, check, not null, default
--  1.	Create a new database named and Customers_Orders and add the following tables as per the description

CREATE DATABASE CUSTOMERS_ORDERS;
-- a.	Create a table named Customers to store customer information. Include the following columns:
 USE customers_orders;
 
 create table Customers (Customerid int primary key auto_increment,First_name varchar(50),Last_name varchar(50) ,Email varchar(255) not null ,Mobile_No varchar(20));
 alter TABLE customers modify First_name varchar(50) not null;
 alter table customers modify Last_name varchar(50) not null;
 
 -- b.	Create a table named Orders to store information about customer orders. Include the following columns:
 create table orders(Order_id int primary KEY auto_increment,Customer_id  int ,Order_date date ,Total_Amount decimal(10,2));
 
-- Constraints:
-- a)	Set a FOREIGN KEY constraint on customer_id to reference the Customers table.
 alter table orders add constraint order01  foreign key(Customer_id) references customers(customerid);
 -- b)	Add a CHECK constraint to ensure the total_amount is always a positive value.
 alter table orders add constraint order01  check(Total_Amount>0);
-- sc Order;
 
 
 -- join 
 -- 1.	List the top 5 countries (by order count) that Classic Models ships to. (Use the Customers and Orders tables)
select * from customers;
select * from orders;
SELECT c.country,count(o.orderNumber) as order_count from customers c join orders o on o.customerNumber=c.customerNumber
group by c.country order by order_count desc limit 5;

--  self join 
-- 2.	Create a table project with below fields.
Create table  Project(EmployeeID int primary key auto_increment,FullName  varchar(50) not null ,Gender enum('Male','Female'),ManagerId int);
desc project;
insert into project(FullName,Gender,ManagerId)values('Pranaya','Male',3),('Priyanka','Female',1),('preety','Female',null);
insert into project(FullName,Gender,ManagerId)values('Anurag','Male',1),('Sambit','Male',1),('Rajesh','Male',3),('Hina','Female',3);
select * from project;
select * from project T1 join Project T2 on 1EmployeeID=T1.Mnagerid;
select * from project T1 join Project T2 on T1.EmployeeID=T2.Managerid;
select T1.Fullname as EmployeeName,T2.FullName as ManagerName from project T1 join Project T2 on T1.EmployeeID=T2.Managerid;



-- DDL Commands: Create, Alter, Rename
-- 1.	Create table facility. Add the below fields into it.
create table Facility(FacilityId int,`Name` varchar(50),State varchar(50),Country varchar(50));
-- i) Alter the table by adding the primary key and auto increment to Facility_ID column.
alter table Facility  modify Facility_id int primary key auto_increment;
  -- ii) Add a new column city after name with data type as varchar which should not accept any null values.
Alter table Facility add City varchar(50) not null after `Name`;



-- Views in SQL
-- 1.	Create a view named product_category_sales that provides insights into sales performance by product category. This view should include the following information:
CREATE VIEW product_category_sales AS
SELECT 
    pl.productLine,
    SUM(od.quantityOrdered * od.priceEach) AS total_sales,
    COUNT(DISTINCT o.orderNumber) AS number_of_orders
FROM 
    ProductLines pl
JOIN 
    Products p ON pl.productLine = p.productLine
JOIN 
    OrderDetails od ON p.productCode = od.productCode
JOIN 
    Orders o ON od.orderNumber = o.orderNumber
GROUP BY 
    pl.productLine;
SELECT * FROM product_category_sales;

-- Stored Procedures in SQL with parameters
-- 1.	Create a stored procedure Get_country_payments which takes in year and country as inputs and gives year wise, country wise total amount as an output. Format the total amount to nearest thousand unit (K)
DELIMITER //
CREATE PROCEDURE Get_country_payment4(IN INPUT_YEAR INT ,INPUT_COUNTRY VARCHAR(40))
BEGIN 
select year(P.PaymentDate),C.Country,p.Amount from customers C join Payments P on c.customerNumber= P.customerNumber where YEAR(P.PaymentDate)=INPUT_YEAR AND C.Country=INPUT_COUNTRY
Group by Country;
end //
call Get_country_payment4(2003,'France');




------------------------------------------------------------------------------------------
-- Window functions - Rank, dense_rank, lead and lag
-- 1a) Using customers and orders tables, rank the customers based on their order frequency
SELECT 
    c.customerNumber,
    c.customerName,
    COUNT(o.orderNumber) AS orderFrequency,
    RANK() OVER (ORDER BY COUNT(o.orderNumber) DESC) AS customerRank
FROM 
    Customers c
LEFT JOIN 
    Orders o ON c.customerNumber = o.customerNumber
GROUP BY 
    c.customerNumber, c.customerName
ORDER BY 
    orderFrequency DESC;
-- 1b) Calculate year wise, month name wise count of orders and year over year (YoY) percentage change. Format the YoY values in no decimals and show in % sign.
SELECT
    YEAR(orderDate) AS orderYear,
    MONTHNAME(orderDate) AS monthName,
    COUNT(*) AS orderCount,
    CONCAT(FORMAT(
        ((COUNT(*) - LAG(COUNT(*), 12) OVER (ORDER BY YEAR(orderDate), MONTH(orderDate))) / NULLIF(LAG(COUNT(*), 12) OVER (ORDER BY YEAR(orderDate), MONTH(orderDate)), 0)) * 100,
        0
    ), '%') AS YoYPercentageChange
FROM
    Orders
GROUP BY
    orderYear, MONTH(orderDate)
ORDER BY
    orderYear, MONTH(orderDate);
    
    
    -- Subqueries and their applications
    -- 1.	Find out how many product lines are there for which the buy price value is greater than the  average of buy price value. Show the output as product line and its count.
   
  SELECT productLine, COUNT(*) as Total
FROM products
WHERE buyPrice > (SELECT AVG(buyPrice) FROM products)
GROUP BY productLine;

   
   
   
   
   
   
   -- ERROR HANDLING in SQL
   -- 1.	Create the table Emp_EH. Below are its fields.
   -- Create a procedure to accept the values for the columns in Emp_EH. Handle the error using exception handling concept. Show the message as “Error occurred” in case of anything wrong.


   CREATE TABLE Emp_EH (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(255),
    EmailAddress VARCHAR(255)
);

-- Create the procedure with error handling
DELIMITER //

CREATE PROCEDURE Insert_Emp_EH(
    IN p_EmpID INT,
    IN p_EmpName VARCHAR(255),
    IN p_EmailAddress VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION

        -- Error occurred
SELECT 'Error occurred' AS Message;
    END //

    -- Attempt to insert into the table
    ---------------------------------------------------------------------------------------------------------------
    
    -- TRIGGERS
    -- 1.	Create the table Emp_BIT. Add below fields in it.
    -- Create before insert trigger to make sure any new value of Working_hours, if it is negative, then it should be inserted as positive
    
    -- Create the Emp_BIT tabl
CREATE TABLE Emp_EH (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(255),
    EmailAddress VARCHAR(255)
);
INSERT INTO Emp_BIT VALUES
('Robin', 'Scientist', '2020-10-04', 12),  
('Warner', 'Engineer', '2020-10-04', 10),  
('Peter', 'Actor', '2020-10-04', 13),  
('Marco', 'Doctor', '2020-10-04', 14),  
('Brayden', 'Teacher', '2020-10-04', 12),  
('Antonio', 'Business', '2020-10-04', 11);

DELIMITER //

CREATE TRIGGER before_insert_Working_hours
BEFORE INSERT ON Emp_BIT
FOR EACH ROW
BEGIN
    IF NEW.Working_hours < 0 THEN
        SET NEW.Working_hours = -NEW.Working_hours;
    END IF;
END;
//


INSERT INTO Emp_BIT VALUES ('John', 'Manager', '2020-10-05', -10);

